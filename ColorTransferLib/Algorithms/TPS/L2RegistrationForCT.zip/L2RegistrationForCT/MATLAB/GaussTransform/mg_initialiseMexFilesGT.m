mex mex_CJianCost.c CJianCost.c
mex mex_GaussTransform.c GaussTransform.c