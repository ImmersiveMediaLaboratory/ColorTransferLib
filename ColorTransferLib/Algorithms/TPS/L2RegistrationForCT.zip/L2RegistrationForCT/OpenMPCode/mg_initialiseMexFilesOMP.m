mex -g  mex_mgRecolourParallel_1.cpp
mex -g  mex_mgRecolourParallel_Mask.cpp
mex -g  mex_mgRecolourParallelTPS.cpp